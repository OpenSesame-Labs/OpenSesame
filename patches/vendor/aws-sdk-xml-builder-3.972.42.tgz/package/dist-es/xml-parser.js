import { parseXML as parseLegacyXML } from "./xml-parser-legacy";
import { XMLValidator } from "fast-xml-parser";

// Preserve the previous XML decoder's object-key safety policy.
const CRITICAL_XML_NAMES = new Set(["__proto__", "constructor", "prototype"]);
const RESERVED_XML_NAMES = new Set([
    "hasOwnProperty", "toString", "valueOf", "__defineGetter__", "__defineSetter__",
    "__lookupGetter__", "__lookupSetter__",
]);
function safeXmlName(name) {
    if (CRITICAL_XML_NAMES.has(name)) {
        throw new Error(`[SECURITY] Invalid XML name: ${name}`);
    }
    return RESERVED_XML_NAMES.has(name) ? `__${name}` : name;
}

function writeKey(obj) {
    Object.defineProperty(obj, "__proto__", { value: undefined, writable: true, enumerable: true, configurable: true });
}
export function parseXML(xml) {
    if (/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(xml)) {
        throw new Error("@aws-sdk XML parse error: invalid control character.");
    }
    const state = new AwsXmlParser(xml);
    return state.parse();
}
class AwsXmlParser {
    x;
    i = 0;
    z;
    doctypeSeen = false;
    constructor(x) {
        this.x = x;
        this.x = x.replace(/^\ufeff/, "").replace(/\r\n?/g, "\n");
        this.z = this.x.length;
    }
    parse() {
        const p = this;
        const { z } = p;
        while (p.i < z) {
            p.trim();
            if (p.i >= z) {
                break;
            }
            if (p.isNext("<?")) {
                p.readTo("?>");
                p.trim();
            }
            else if (p.isNext("<!--")) {
                p.readTo("-->");
                p.trim();
            }
            else if (p.isNext("<!DOCTYPE", false)) {
                if (p.doctypeSeen) throw new Error("@aws-sdk XML parse error: duplicate DOCTYPE.");
                p.doctypeSeen = true;
                const doctypeStart = p.i;
                p.skipDoctype();
                // The upstream validator misreads '>' inside a quoted DTD
                // value. Validate the surrounding document separately; the
                // legacy parser validates and bounds the declarations.
                const validation = XMLValidator.validate(p.x.slice(0, doctypeStart) + p.x.slice(p.i));
                if (validation !== true) {
                    throw new Error(`@aws-sdk XML parse error: ${validation.err.msg}`);
                }
                p.parse();
                return parseLegacyXML(p.x, false);
            }
            else if (p.x[p.i] === "<") {
                if (!p.doctypeSeen) {
                    const validation = XMLValidator.validate(p.x);
                    if (validation !== true) {
                        throw new Error(`@aws-sdk XML parse error: ${validation.err.msg}`);
                    }
                }
                const root = p.parseTag();
                p.trim();
                while (p.i < z) {
                    if (p.isNext("<!--")) p.readTo("-->");
                    else if (p.isNext("<?")) p.readTo("?>");
                    else throw new Error("@aws-sdk XML parse error: unexpected content after root.");
                    p.trim();
                }
                return { [root.tag]: root.value };
            }
            else {
                throw new Error("@aws-sdk XML parse error: unexpected content.");
            }
        }
        throw new Error("@aws-sdk XML parse error: no root element.");
    }
    isNext(s, caseSensitive = true) {
        const p = this;
        if (caseSensitive) {
            return p.x.startsWith(s, p.i);
        }
        return p.x.toLowerCase().startsWith(s.toLowerCase(), p.i);
    }
    readTo(stop) {
        const p = this;
        const _i = p.x.indexOf(stop, p.i);
        if (_i === -1) {
            throw new Error(`@aws-sdk XML parse error: expected "${stop}" not found.`);
        }
        const result = p.x.slice(p.i, _i);
        p.i = _i + stop.length;
        return result;
    }
    trim() {
        const p = this;
        while (p.i < p.z && " \t\r\n".includes(p.x[p.i])) {
            ++p.i;
        }
    }
    readAttrValue() {
        const p = this;
        const quote = p.x[p.i];
        if (quote !== "\"" && quote !== "'") {
            throw new Error("@aws-sdk XML parse error: attribute values must be quoted.");
        }
        ++p.i;
        let value = "";
        while (p.i < p.z && p.x[p.i] !== quote) {
            value += p.x[p.i++];
        }
        if (p.i >= p.z) {
            throw new Error("@aws-sdk XML parse error: unclosed attribute value.");
        }
        ++p.i;
        return p.decodeEntities(value);
    }
    parseTag(depth = 0) {
        const p = this;
        if (depth > 256) {
            throw new Error("@aws-sdk XML parse error: maximum nesting exceeded.");
        }
        ++p.i;
        let tag = "";
        while (p.i < p.z && !" \t\r\n>/".includes(p.x[p.i])) {
            tag += p.x[p.i++];
        }
        const outputTag = safeXmlName(tag);
        let hasAttrs = false;
        const attrs = {};
        const seenAttributes = new Set();
        while (p.i < p.z) {
            p.trim();
            if (">/".includes(p.x[p.i])) {
                break;
            }
            let name = "";
            while (p.i < p.z && !"= \t\r\n>/?".includes(p.x[p.i])) {
                name += p.x[p.i++];
            }
            p.trim();
            if (p.x[p.i] !== "=") {
                break;
            }
            ++p.i;
            p.trim();
            if (seenAttributes.has(name)) {
                throw new Error("@aws-sdk XML parse error: duplicate attribute.");
            }
            seenAttributes.add(name);
            attrs[safeXmlName(name)] = p.readAttrValue();
            hasAttrs = true;
        }
        if (p.i >= p.z) {
            throw new Error("@aws-sdk XML parse error: unexpected end of input.");
        }
        if (p.x[p.i] === "/") {
            ++p.i;
            if (p.i >= p.z || p.x[p.i] !== ">") {
                throw new Error("@aws-sdk XML parse error: expected > at the end of self-closing tag.");
            }
            ++p.i;
            return { tag: outputTag, value: hasAttrs ? attrs : "" };
        }
        if (p.x[p.i] !== ">") {
            throw new Error("@aws-sdk XML parse error: expected > at the end of opening tag.");
        }
        ++p.i;
        const textParts = [];
        const childTags = [];
        let hasElementChild = false;
        while (p.i < p.z) {
            if (p.isNext("</")) {
                break;
            }
            if (p.x[p.i] === "<") {
                if (p.isNext("<!--")) {
                    p.readTo("-->");
                }
                else if (p.isNext("<![CDATA[")) {
                    p.i += 9;
                    textParts.push(p.readTo("]]>"));
                }
                else if (p.isNext("<?")) {
                    p.readTo("?>");
                }
                else {
                    hasElementChild = true;
                    childTags.push(p.parseTag(depth + 1));
                }
            }
            else {
                let text = "";
                while (p.i < p.z && p.x[p.i] !== "<") {
                    text += p.x[p.i++];
                }
                textParts.push(p.decodeEntities(text));
            }
        }
        if (!p.isNext("</")) {
            throw new Error(`@aws-sdk XML parse error: missing closing tag </${tag}>.`);
        }
        p.i += 2;
        const closeTag = p.readTo(">").trim();
        if (closeTag !== tag) {
            throw new Error(`@aws-sdk XML parse error: mismatched tags <${tag}> and </${closeTag}>.`);
        }
        if (!hasAttrs && textParts.length === 0 && !hasElementChild) {
            return { tag: outputTag, value: "" };
        }
        if (!hasAttrs && !hasElementChild) {
            const text = textParts.length === 1 ? textParts[0] : textParts.join("");
            if (text.trim() === "" && text.includes("\n")) {
                return { tag: outputTag, value: "" };
            }
            return { tag: outputTag, value: text };
        }
        const obj = {};
        for (const text of textParts) {
            if (text.trim() === "" && text.includes("\n")) {
                continue;
            }
            obj["#text"] = "#text" in obj ? obj["#text"] + text : text;
        }
        for (const child of childTags) {
            if (Object.prototype.hasOwnProperty.call(obj, child.tag)) {
                if (Array.isArray(obj[child.tag])) {
                    obj[child.tag].push(child.value);
                }
                else {
                    obj[child.tag] = [obj[child.tag], child.value];
                }
            }
            else {
                if (child.tag === "__proto__") {
                    writeKey(obj);
                }
                obj[child.tag] = child.value;
            }
        }
        for (const [k, v] of Object.entries(attrs)) {
            if (k === "__proto__") {
                writeKey(obj);
            }
            obj[k] = v;
        }
        return { tag: outputTag, value: obj };
    }
    static ENTITIES = {
        amp: "&",
        lt: "<",
        gt: ">",
        quot: '"',
        apos: "'",
        // Legacy mappings from @nodable/entities v2.1.0, copyright Amit Gupta, MIT.
        nbsp: "\u00a0", copy: "\u00a9", reg: "\u00ae", trade: "\u2122",
        mdash: "\u2014", ndash: "\u2013", hellip: "\u2026", laquo: "\u00ab",
        raquo: "\u00bb", lsquo: "\u2018", rsquo: "\u2019", ldquo: "\u201c",
        rdquo: "\u201d", bull: "\u2022", para: "\u00b6", sect: "\u00a7",
        deg: "\u00b0", frac12: "\u00bd", frac14: "\u00bc", frac34: "\u00be",
        cent: "\u00a2", pound: "\u00a3", curren: "\u00a4", yen: "\u00a5",
        euro: "\u20ac", dollar: "$", fnof: "\u0192", inr: "\u20b9", af: "\u060b",
        birr: "\u1265\u122d", peso: "\u20b1", rub: "\u20bd", won: "\u20a9",
        yuan: "\u00a5", cedil: "\u00b8",
    };
    skipDoctype() {
        const p = this;
        p.i += 9;
        let depth = 0;
        while (p.i < p.z) {
            const c = p.x[p.i];
            if (p.isNext("<!--")) {
                p.readTo("-->");
                continue;
            }
            if (c === "\"" || c === "'") {
                ++p.i;
                p.readTo(c);
                continue;
            }
            if (c === "[") {
                ++depth;
            }
            else if (c === "]") {
                --depth;
            }
            else if (c === ">" && depth === 0) {
                ++p.i;
                return;
            }
            ++p.i;
        }
        throw new Error("@aws-sdk XML parse error: unclosed DOCTYPE.");
    }
    decodeEntities(s) {
        return s.replace(/&(?:#x([0-9a-fA-F]+)|#(\d+)|([a-zA-Z][a-zA-Z0-9]{0,30}));/g, (match, hex, dec, named) => {
            if (hex || dec) {
                const codePoint = parseInt(hex || dec, hex ? 16 : 10);
                if (!Number.isFinite(codePoint) || codePoint > 0x10ffff) return match;
                if (codePoint === 0 || (codePoint >= 0xd800 && codePoint <= 0xdfff)) return "";
                return String.fromCodePoint(codePoint);
            }
            return Object.prototype.hasOwnProperty.call(AwsXmlParser.ENTITIES, named)
                ? AwsXmlParser.ENTITIES[named]
                : match;
        });
    }
}
