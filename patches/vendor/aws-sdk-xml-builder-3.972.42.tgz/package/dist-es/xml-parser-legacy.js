import { XMLParser } from "fast-xml-parser";
import { COMMON_HTML, CURRENCY, EntityDecoderImpl, XML } from "./xml-external/nodable_entities";
const entityDecoder = new EntityDecoderImpl({
    namedEntities: { ...XML, ...COMMON_HTML, ...CURRENCY },
    numericAllowed: true,
    limit: {
        // Only custom entities count toward these limits; standard XML and
        // HTML entities remain available for ordinary AWS response bodies.
        maxTotalExpansions: 10000,
        maxExpandedLength: 1000000,
    },
    ncr: {
        xmlVersion: 1.1,
    },
});
const parser = new XMLParser({
    attributeNamePrefix: "",
    processEntities: {
        enabled: true,
        maxTotalExpansions: 10000,
        maxExpandedLength: 1000000,
    },
    htmlEntities: true,
    entityDecoder: {
        setExternalEntities: (entities) => {
            entityDecoder.setExternalEntities(entities);
        },
        addInputEntities: (entities) => {
            entityDecoder.addInputEntities(entities);
        },
        reset: () => {
            entityDecoder.reset();
        },
        decode: (text) => {
            return entityDecoder.decode(text);
        },
        setXmlVersion: (version) => void {},
    },
    ignoreAttributes: false,
    ignoreDeclaration: true,
    parseTagValue: false,
    trimValues: false,
    tagValueProcessor: (_, val) => (val.trim() === "" && val.includes("\n") ? "" : undefined),
    maxNestedTags: 256,
});
export function parseXML(xmlString, validate = true) {
    return parser.parse(xmlString, validate);
}
